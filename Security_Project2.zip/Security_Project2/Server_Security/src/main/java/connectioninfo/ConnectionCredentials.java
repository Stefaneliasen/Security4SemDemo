package connectioninfo;
 public class ConnectionCredentials {
     public static String getURL() {
        return "jdbc:mysql://46.101.217.233:3306/security";
    }
     public static String getId() {
        return "user";
    }
     public static String getPw() {
        return "Kode0871";
    }
 }
