package entities;

public class QueryMessage {

    private String query;

    public QueryMessage(String query) {
        this.query = query;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }
}
