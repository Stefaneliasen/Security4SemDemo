import React, { Component } from 'react';
import { StartPageWrapper } from './my_styled_components';

class StartPage extends Component {
    render() {
        return (
            <StartPageWrapper>
            <h1>Welcome to our security project!</h1>
            </StartPageWrapper>
        );
    }
}

export default StartPage;