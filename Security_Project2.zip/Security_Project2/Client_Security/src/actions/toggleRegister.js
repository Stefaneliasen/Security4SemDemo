export const TOGGLE_REGISTER = "TOGGLE_REGISTER";

export function toggleRegister() {
    return {
        type: TOGGLE_REGISTER
    }
}