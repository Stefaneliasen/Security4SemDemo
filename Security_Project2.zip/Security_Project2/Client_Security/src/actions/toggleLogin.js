export const TOGGLE_LOGIN = "TOGGLE_LOGIN";

export function toggleLogin() {
    return {
        type: TOGGLE_LOGIN
    }
}